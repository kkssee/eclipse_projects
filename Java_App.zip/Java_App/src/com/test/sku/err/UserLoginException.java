package com.test.sku.err;

public class UserLoginException extends Exception
{
	public UserLoginException() {}

	public UserLoginException(String message) {
		super(message);
	}
	
}
