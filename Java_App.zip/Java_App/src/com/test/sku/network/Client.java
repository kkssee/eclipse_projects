package com.test.sku.network;

import java.net.*;
import java.io.*;
import java.util.*;

public class Client {
	static Scanner kbd = new Scanner(System.in);

	public static void main(String[] args) {
		// 클라이언트 소켓 이용하여 서버에 접속
		try {
			Socket s = new Socket("220.67.113.226", 5112);

			InputStream in = s.getInputStream();
			ObjectInputStream ois = new ObjectInputStream(in);
			ChatMsg cm = (ChatMsg)ois.readObject();
			System.out.print(cm.msg + ": ");
			
			String uid = kbd.next();
			String pwd = kbd.nextLine().trim();
			
			// 출력 스트림
			ChatMsg cm2 = new ChatMsg(true, uid, pwd);
			OutputStream out = s.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(out);
			oos.writeObject(cm2);
			oos.flush();
			
			cm = (ChatMsg)ois.readObject();
			
			if(cm.msg.equals("로그인 성공")) {
				new ReadMsg(uid, ois, uid).start();
				while(true) {
					System.out.print("Whisper(s) Public(p) file(a) exit(x): ");
					String msg = kbd.nextLine().trim();
					switch(msg) {
					case "s": {
						System.out.print("보낼 유저: ");
						String to = kbd.nextLine().trim();
						System.out.print("보낼 메시지: ");
						msg = kbd.nextLine().trim();
						System.out.print("파일명: ");
						String fname = kbd.nextLine().trim();
						
						byte[] fdata = FileIO.attachFile(fname);
						boolean isSecret = true;
						cm = new ChatMsg(uid, to, msg, isSecret, fname, fdata);
						oos.writeObject(cm);
						oos.flush();
						break;
					}
					case "p": {
						System.out.print("메시지: ");
						msg = kbd.nextLine().trim();
						if(msg.equalsIgnoreCase("x")) {
							System.out.println("채팅 종료");
							oos.close();
							ois.close();
							s.close();
							break;
						}
						new WriteMsg(uid, oos, msg).start();
					}
					case "x": {
						System.out.println("채팅 종료");
						oos.close();
						ois.close();
						s.close();
						break;
					}
					case "y": {
						String fname = ReadMsg.chatMsg.fname;
						byte[] fdata = ReadMsg.chatMsg.fdata;
						FileIO.download(fname, fdata);
						break;
					}
					}
				}
			} else System.out.println("로그인 실패!");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("클라이언트 종료");
	}

}
