package com.test.sku.network;

public class NetworkMain {
	public static void main(String[] args) {
		/* IP Address : 특정 컴퓨터 지정
		 * Port 번호 : 0~65536, 1024 이후의 포트번호 설정
		 * TCP/IP : Socket, ServerSocket
		 * Client : Socket(통신용, 접속요청)
		 * Server : ServerSocket(접속 대기용), Client(통신용) 
		 */
		
	} // end of main

}
