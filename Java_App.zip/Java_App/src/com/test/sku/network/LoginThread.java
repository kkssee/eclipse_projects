package com.test.sku.network;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class LoginThread implements Runnable {
	
	Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;

	public LoginThread(Socket s) {
		this.s = s;
	}

	@Override
	public void run() {
		OutputStream out;
		try {
			out = s.getOutputStream();
			oos = new ObjectOutputStream(out);
			ChatMsg cm = new ChatMsg("서버", "클라이언트", "아이디 암호");
			oos.writeObject(cm);
			oos.flush();

			InputStream in = s.getInputStream();
			ois = new ObjectInputStream(in);
			
			ChatMsg cm2 = (ChatMsg)ois.readObject();
			System.out.println(cm2.uid + " " + cm2.pwd);
			
			if(cm2.uid.length()>3&&cm2.pwd.length()>3) {
				ChatThread.user.put(cm2.uid, oos);
				new ChatThread(cm2.uid, this.s, this.ois, this.oos).start();
			} else { 
				ChatMsg cm3 = new ChatMsg("서버", "클라이언트", "로그인 실패");
				oos.writeObject(cm3);
				oos.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.err.println("LoginThread dead!");
	}
}
