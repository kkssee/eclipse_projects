package com.test.sku.superpet;

import java.util.List;
import java.util.Scanner;

import com.test.sku.textio.BoardVO;
import com.test.sku.textio.DataIO;

public class UserIO {
	static Scanner kbd = new Scanner(System.in);

	public static String showMenu() {
		System.out.print("add(a) list(s) find(f) update(u) delete(d) exit(x): ");
		String menu = kbd.nextLine().trim();
		return menu;
	}

	public static void addMenu() {
		System.out.print("Cat(c) Dog(d) Snake(s) Hamster(h): ");
		String m = kbd.nextLine().trim();
		String s = null;
		
		switch (m) {
			case "c": {
				System.out.print("Price Breed Age Pattern: ");
				s = kbd.nextLine().trim();
				break;
			} case "d": {
				System.out.print("Price Breed Age Weight: ");
				s = kbd.nextLine().trim();
				break;
			} case "s": {
				System.out.print("Price Breed Size Pattern: ");
				s = kbd.nextLine().trim();
				break;
			} case "h": {
				System.out.print("Price Breed Size: ");
				s = kbd.nextLine().trim();
				break;
			} default: System.err.println("Wrong input!\n"); return;
		}
		boolean added = FileIO.addPet(m, s);
		if(added) System.out.println("Pet added !\n"); 
		else System.err.println("Addition failed !\n"); 
	}
	
	public static void listMenu() 
	{
		System.out.println("\n\t     *** List ***");
		System.out.printf("%-8s\t%-15s%-8s\t%-8s\t%-8s\t%s%n", "price", "breed", "age", "pattern", "weight", "size");
		System.out.println("------------------------------------------------------------------------------");  
		List<Pet> list = FileIO.getList();
		
		for(int i = 0; i < list.size(); i++)
		{
			System.out.println(list.get(i));
		}
		System.out.println();
	}

	public static void findMenu() {
		System.out.print("펫 breed로 검색: ");
		String f = kbd.nextLine();
		
		int idx = FileIO.findPet(f);
		List<Pet> list = FileIO.getList();
		
		System.out.printf("%-8s\t%-15s%-8s\t%-8s\t%-8s\t%s%n", "price", "breed", "age", "pattern", "weight", "size");
		System.out.println("------------------------------------------------------------------------------");

		if(list.get(idx) != null)
		{
			System.out.println(list.get(idx));
			System.out.println();
		} else {
			System.err.println("검색된 펫이 없습니다.");
		}
	}

	/*public static void updateMenu() {
		System.out.print("수정할 펫 breed: ");
		
		List<Pet> list = FileIO.getList();
		String f = kbd.nextLine();
		int idx = FileIO.findPet(f);
		System.out.println(list.get(idx));
		
		System.out.print("수정하시겠습니까?(Y/N) ");
		String c = kbd.nextLine().trim();
		
		if(c.equals("Y")||c.equals("y")) {
			System.out.print(": ");
			String title = kbd.nextLine();
			System.out.print("내용: ");
			String contents = kbd.nextLine();
			
			boolean saved = DataIO.updateBoard(idx, title, contents);
			if(saved) System.out.println("\t\t수정 성공");
			else System.err.println("\t\t수정 실패");
		} else System.out.println("취소"); return;
	}*/

	/*public static void deleteMenu() {
		System.out.print("삭제할 펫 breed: ");
		
		List<Pet> list = FileIO.getList();
		String f = kbd.nextLine();
		int idx = FileIO.findPet(f);
		System.out.println(list.get(idx));
		
		System.out.print("삭제하시겠습니까?(Y/N) ");
		String c = kbd.nextLine().trim();
		
		if(c.equals("Y")||c.equals("y")) {
			boolean deleted = FileIO.deletePet(idx);
			if(deleted) System.out.println("\t\t삭제 성공");
			else System.err.println("\t\t삭제 실패");
		} else System.out.println("취소"); return;
	}*/

}
