package com.test.sku.superpet;

public class Snake extends Pet {
	float size;
	String pattern;
	
	
	public Snake() { }
	public Snake(int price, String breed, float size, String pattern) {
		super(price, breed);
		setSize(size);
		setPattern(pattern);
	}

	@Override
	public String toString() {
		return super.toString()+"\t\t"+pattern+"\t\t\t\t"+size+" inches";
	}
	
	public float getSize() {
		return size;
	}
	public void setSize(float size) {
		this.size = size;
	}
	public String getPattern() {
		return pattern;
	}
	public void setPattern(String pattern) {
		this.pattern = pattern;
	} 
	
	
}
