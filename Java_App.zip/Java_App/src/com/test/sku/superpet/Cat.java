package com.test.sku.superpet;

public class Cat extends Pet {
	float age;
	String pattern;
	
	public Cat() { }
	public Cat(int price, String breed, float age, String pattern) {
		super(price, breed);
		setAge(age);
		setPattern(pattern);
	}

	@Override
	public String toString() {
		return super.toString()+age+"\t"+pattern;
	}
	
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public String getPattern() {
		return pattern;
	}
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	
	
}
