package com.test.sku.superpet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.test.sku.textio.BoardVO;

public class FileIO {
	static Scanner kbd = new Scanner(System.in);
	static String fpath = "C:/test/data/superPets.txt";
	
	public static boolean addPet(String m, String petInfo) {
		String[] str = petInfo.split("\\s+");
		List<Pet> list = getList(); 
		
		switch (m) {
			case "c": {
				Cat pet = new Cat(Integer.parseInt(str[0]), str[1], Float.parseFloat(str[2]), str[3]);
				list.add(pet);
				overwrite(list); return true;  
			} case "d": {
				Dog pet = new Dog(Integer.parseInt(str[0]), str[1], Float.parseFloat(str[2]), Float.parseFloat(str[3]));
				list.add(pet);
				overwrite(list); return true;  
			} case "s": {
				Snake pet = new Snake(Integer.parseInt(str[0]), str[1], Float.parseFloat(str[2]), str[3]);
				list.add(pet);
				overwrite(list); return true;  
			} case "h":  {
				Hamster pet = new Hamster(Integer.parseInt(str[0]), str[1], Float.parseFloat(str[2]));
				list.add(pet);
				overwrite(list); return true; 
			}
		}	
		return false;
	}
	public static boolean overwrite(List<Pet> list) 
	{
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fpath)); 
			oos.writeObject(list);
			oos.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	public static List<Pet> getList() 
	{
		try {
			File ser = new File(fpath);
			if(!ser.exists())	// 직렬화 파일이 없는 경우
			{
				List<Pet> list = new ArrayList<>();
				overwrite(list);
			}
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fpath));
			List<Pet> list = (List<Pet>)ois.readObject();
			ois.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static int findPet(String f) {
		List<Pet> list = getList(); 
		Pet key = new Pet(f);
		
		if(list.contains(key))
		{
			int idx = list.indexOf(key);
			return idx;
		}
		return 0;
	}
	/*public static boolean deletePet(int idx) {
		List<Pet> list = getList(); 
		
		try {
			list.remove(idx);
			
			PrintWriter out = new PrintWriter(new FileWriter(fpath));
			for(int i = 0; i < list.size(); i++)
			{
				Pet p = list.get(i); 
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String sDate = sdf.format(p.getRegDate());

				out.printf("%d|%s|%s|%s|%d|%s%n", 
						p.getNo(), p.getTitle(), b.getAuthor(), sDate, b.getHits(), b.getContents());
				out.flush();
			}
			out.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}*/
}
