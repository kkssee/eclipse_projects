package com.test.sku.superpet;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Pet implements Serializable{
	
	int price;
	String breed;
	
	public Pet() {}
	public Pet(int price, String breed) {
		super();
		this.price = price;
		this.breed = breed;
	}
	public Pet(String f) {
		setBreed(f);
	}
	
	@Override
	public boolean equals(Object obj) {
		Pet other = (Pet) obj;
		return this.getBreed().equals(other.getBreed());
	}
	@Override
	public String toString() {
		DecimalFormat nf = new DecimalFormat("#,###");
		//DecimalFormat df = new DecimalFormat("#.##");

		return String.format("%-8s\t%-15s", nf.format(price), breed);
	}
	
	public int getPrice() {
		return price;
	}
	public String getBreed() {
		return breed;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}

}
