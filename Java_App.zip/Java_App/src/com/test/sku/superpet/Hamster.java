package com.test.sku.superpet;

public class Hamster extends Pet {
	float size;

	public Hamster() { }
	public Hamster(int price, String breed, float size) {
		super(price, breed);
		setSize(size);
	}

	@Override
	public String toString() {
		return super.toString()+"\t\t\t\t"+size+" kg";
	}
	
	public float getSize() {
		return size;
	}

	public void setSize(float size) {
		this.size = size;
	}
	
	
}
