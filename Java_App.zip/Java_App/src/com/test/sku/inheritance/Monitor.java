package com.test.sku.inheritance;

import java.text.DecimalFormat;
import java.util.Date;

public class Monitor extends Item {
	float size;
	
	public Monitor() {}
	public Monitor(String name, String made, int price, Date pDate, float size) {
		super(name, made, price, pDate);
		setSize(size);
	}
	public Monitor(String name, String made, int price, String sDate, float size) {
 		super(name, made, price, sDate);
 		setSize(size);
 	}
 	
 	@Override
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		return super.toString()+"\t"+df.format(size)+" inches";
	}
	
	public float getSize() {
		return size;
	}
	public void setSize(float size) {
		this.size = size;
	}
}
